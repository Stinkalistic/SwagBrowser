Thanks 4 installing swagbrowser - Stinkalistic

DEPENDCIES:
Install requests and also install cmu graphics with "pip install cmu-graphics" All the other dependencies come installed with python I think

HOW TO USE:
run browser.py and enter the url. If it crashes or something, make an issue on https://github.com/Stinkalistic/SwagBrowser/issues.
Use arrow keys to scroll through the website. You can adjust scrolling speed, text and background color, or turn on dark mode in settings.cfg
You can also open a local html document by running parser.py and giving it the name of a file or just the html directly
Press B to bookmark a website which so it will be saved in bookmarks.txt and you can easily access it in the browser
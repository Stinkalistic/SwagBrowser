Thanks 4 installing swagbrowser - Stinkalistic

DEPENDCIES:
Install requests and also install cmu graphics with "pip install cmu-graphics" All the other dependencies come installed with python I think

HOW TO USE:
run browser.py and enter the url. If it crashes or something, make an issue on https://github.com/Stinkalistic/SwagBrowser/issues.